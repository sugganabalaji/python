#NumberDivisionError.py<---File Name and Module Name
class NumberDivisionError(Exception):pass

#Phase-1: Development of Programmer-Defined Exception Sub Class