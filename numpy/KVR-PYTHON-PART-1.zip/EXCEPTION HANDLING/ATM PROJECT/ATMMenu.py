#ATMMenu.py
def menu():
    print("="*50)
    print("ATM OR Funds Transfer Application")
    print("=" * 50)
    print("\t1. Deposit")
    print("\t2. Withdraw")
    print("\t3. Bal Enq")
    print("\t4. Exit")
    print("=" * 50)
