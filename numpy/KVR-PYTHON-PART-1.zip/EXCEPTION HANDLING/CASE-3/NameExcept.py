#NameExcept.py<-----File Name and Acts as Module Name
class InvalidNameError(Exception):pass
class ZeroLengthError(BaseException):pass
class SpaceNameError(Exception):pass