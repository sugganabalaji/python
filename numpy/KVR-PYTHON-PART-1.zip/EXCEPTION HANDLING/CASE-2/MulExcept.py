#MulExcept.py
class ZeroError(Exception):pass
class NegNumError(Exception):pass
