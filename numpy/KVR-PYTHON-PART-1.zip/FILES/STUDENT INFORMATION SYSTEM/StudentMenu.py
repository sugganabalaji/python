#StudentMenu.py<---File Name and Module Name
def menu():
    print("*"*50)
    print("\t\tStudent Information System")
    print("*" * 50)
    print('\t1.Add New Student')
    print("\t2.View All Students Details")
    print("\t3.View Single Students Details")
    print("\t4.Delete Student Record")
    print("\t5.Update Student Record")
    print("\t6.Search Student Record")
    print("\t7.Exit")
    print("*" * 50)
