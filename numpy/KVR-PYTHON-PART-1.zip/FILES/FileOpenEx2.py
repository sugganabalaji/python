#Program for creating the file in write Mode
#FileOpenEx2.py
fp=open("D:\\KVR\\stud2.data","w")
print("Type of fp=",type(fp))
print("File Created and Opened in Write mode")
