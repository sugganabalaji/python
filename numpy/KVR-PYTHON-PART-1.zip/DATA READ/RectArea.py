#Program for Cal Area of Rectangle
#Area=length x Breadth
#Taking Input
length=float(input("Enter Length:"))
breadth=float(input("Enter Breadth:"))
#Cal area of Rect
area=length*breadth
#Display the Result
print("*"*50)
print("\t\tLength={}".format(length))
print("\t\tBreadth={}".format(breadth))
print("\t\tArea of Rect={}".format(area))
print("*"*50)