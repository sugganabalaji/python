#Program for Reading the input from Key Board by using input(Message)
k=input("Enter a Value:")
print(k,type(k))
 
