#Program accepting Two Numerical values and Multiply them
#MulEx6.py
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
print("Mul={}".format(a*b))
