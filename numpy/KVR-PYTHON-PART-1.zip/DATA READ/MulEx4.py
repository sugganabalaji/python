#Program accepting Two Numerical values and Multiply them
#MulEx4.py
print("Enter Two Values:")
a=float(input())
b=float(input())
print("-"*50)
print("First Value:{}".format(a))
print("Second Value:{}".format(b))
print("Mul={}".format(a*b))
