#Program accepting Two Numerical values and Multiply them
#MulEx5.py
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
print("-"*50)
print("First Value:{}".format(a))
print("Second Value:{}".format(b))
print("Mul={}".format(a*b))
print("-"*50)
