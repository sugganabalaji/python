#Program accepting Two Numerical values and Multiply them
#MulEx6.py
print("Mul={}".format(float(input("Enter First Value:"))*float(input("Enter Second Value:"))))
