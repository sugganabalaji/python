#Program for Cal Area  and Perimter of Circle
#CircleAreaPerimter.py
r=float(input("Enter Radius:"))
#cal area of circle
ac=3.14*r*r
#cal Perimter of circle
pc=2*3.14*r
print("="*50)
print("\tRadius:{}".format(r))
print("\tArea of Circle:{}".format(ac))
print("\tPerimeter of Circle:{}".format(pc))
print("="*50)
print("===========OR=======================")
print("="*50)
print("\tRadius:{}".format(r))
print("\tArea of Circle:%0.2f" %ac)
print("\tPerimeter of Circle:%0.2f" %pc)
print("="*50)
