#Program accepting Two Numerical values and Multiply them
#MulEx3.py
print("Enter First Value:")
a=float(input())
print("Enter Second Value:")
b=float(input())
print("-"*50)
print("First Value:{}".format(a))
print("Second Value:{}".format(b))
print("Mul={}".format(a*b))
