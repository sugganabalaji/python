#Program for Reading the input from KBD--input()
print("Enter a Value:")
x=input()
print(x,type(x))
