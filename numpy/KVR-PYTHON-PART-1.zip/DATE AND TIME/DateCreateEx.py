#DateCreateEx.py
import datetime
x = datetime.datetime(2022, 10, 20)
print(x) 