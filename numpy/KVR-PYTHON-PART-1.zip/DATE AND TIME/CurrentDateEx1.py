#CurrentDateEx1.py
from datetime import date 
td=date.today()
print(td)