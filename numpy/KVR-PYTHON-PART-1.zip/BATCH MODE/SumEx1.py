#Program for addition of Two Numbers
a=3
b=4
c=a+b
print(a)
print(b)
print(c)

