#Program for adding of Two Numbers
a=10
b=20
c=a+b
print("-"*50)
print("Val of a=",a)
print("Val of b=",b)
print("Sum=",c)
print("*"*50)
