#Program for Adding Two Numbers
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
c=a+b
print("--------------------------------")
print("Val of a={}".format(a))
print("val of b={}".format(b))
print(f"sum({a},{b})={c}")
print("--------------------------------")



