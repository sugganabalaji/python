#greet.py<--File Name ans
def welcome(val):
	print("Hi {}, Good Morning".format(val))