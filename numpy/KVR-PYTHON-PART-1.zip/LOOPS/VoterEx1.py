#VoterEx1.py
age=int(input("Enter Age of Citizen:"))
if(age>=18):
    print("{} Years Citizen is Eligible to Vote:".format(age))
else:
    print("{} Years Citizen is Not Eligible to Vote:".format(age))
