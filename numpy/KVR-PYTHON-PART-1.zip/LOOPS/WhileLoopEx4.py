#Program for accepting a Word and Display char by char
#WhileLoopEx4.py
word=input("Enter a word:")
i=0
while(i<=len(word)-1):
    print(word[i])
    i=i+1

