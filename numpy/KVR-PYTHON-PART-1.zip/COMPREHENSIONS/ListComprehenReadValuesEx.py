#Program for Reading the Values from KBD by using Comprehension Tech
#ListComprehenReadValuesEx.py
lst=[int(val)  for val in input("Enter List of Values Separated by space:").split()]
print(lst,type(lst))
