#Program for adding of Two  Numbers by using Functions
#INPUT     : Inside the Function Body
#PROCESS   : Inside the Function Body
#RESULT    : Inside the Function Body
#ApprochEx3.py
def addop():
    #Take the Input
    a=float(input("Enter First Value:"))
    b = float(input("Enter Second Value:"))
    #Processing
    c=a+b
    #Display the Result
    print("sum({},{})={}".format(a,b,c))

#Main Program
addop() # Function Call
