
def welcome(): # Function Definition
    print("Welcome to Functions")

#Main Program
print("I am before Function Call")
print("Type of welcome=",type(welcome)) # <class, 'function'>
welcome() # Function Call
print("I am after Function Call")