#Moviee.py
tkt=input("Do u have a Ticket(yes/no):") # yes
if(tkt=="yes"):
    print("Enter into Theater")
    print("Watch the movivee")
    print("Understandthe Message")
print("Goto Home")