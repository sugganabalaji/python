#FromImportStmtEx1.py
from icici import bname,addr,simpleint
from MathsInfo import PI
from Aop import sumop,mulop
print("Bank Name:",bname)
print("Bank Address:",addr)
simpleint()
print("-------------------------")
print("Value of PI=",PI)
print("-------------------------")
sumop(10,20)
mulop(6,7)

