#SE2.py------Program
import Aop
Aop.sumop(10,20)
Aop.subop(3,4)
Aop.mulop(4,5)