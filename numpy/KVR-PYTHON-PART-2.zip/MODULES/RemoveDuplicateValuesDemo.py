#RemoveDuplicateValuesDemo.py
import RemoveDuplicateValues as r
r.RemoveDuplicateValues("MISSISSIPPI")