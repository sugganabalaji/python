#FromImportStmtEx3.py
from icici import *
from MathsInfo import *
from Aop import *
print("Bank Name:",bname)
print("Bank Address:",addr)
simpleint()
print("-------------------------")
print("Value of PI=",PI)
print("-------------------------")
sumop(10,20)
mulop(6,7)

