#FindLargestValueDemo.py
from FindLargestValue import findlarsubstringvalue as fs
fs("kvkkvKvvvvkv")
