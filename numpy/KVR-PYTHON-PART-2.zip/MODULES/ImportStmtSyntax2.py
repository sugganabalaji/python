#Importing multiple Modules at a time in one line
#ImportStmtSyntax2.py
import icici,MathsInfo,Aop
icici.simpleint()
print("Val of PI",MathsInfo.PI)
Aop.mulop(3,4)
