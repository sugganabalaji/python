#Importing one Module at a time with alias Name with Distinct Name
#ImportStmtSyntax3.py
import icici as ic
import MathsInfo as m
import Aop as a
print("Bank Name=",ic.bname)
print('Bank Address=',ic.addr)
ic.simpleint()
print("Val of PI",m.PI)
a.subop(3,4)

