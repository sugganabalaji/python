#SE3.py<---Program
import icici
print("Bank Name=",icici.bname)
print("Bank Addr=",icici.addr)
icici.simpleint()
