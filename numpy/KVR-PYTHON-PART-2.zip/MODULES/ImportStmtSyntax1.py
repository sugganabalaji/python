#Importing one Module at a time
#ImportStmtSyntax1.py
import icici
import MathsInfo
import Aop
icici.simpleint()
print("Val of PI",MathsInfo.PI)
Aop.mulop(3,4)
