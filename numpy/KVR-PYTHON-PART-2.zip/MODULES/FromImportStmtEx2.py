#FromImportStmtEx2.py
from icici import bname as bn,addr as ad,simpleint as si
from MathsInfo import PI as p
from Aop import sumop as sp,mulop as mp
print("Bank Name:",bn)
print("Bank Address:",ad)
si()
print("-------------------------")
print("Value of PI=",p)
print("-------------------------")
sp(10,20)
mp(6,7)

