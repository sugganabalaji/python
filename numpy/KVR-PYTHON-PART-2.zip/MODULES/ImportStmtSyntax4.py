#Importing multiple Modules at a time in one line
#ImportStmtSyntax2.py
import icici as ic,MathsInfo as m,Aop as a
ic.simpleint()
print("Val of PI",m.PI)
a.mulop(3,4)
