#SE1.py<-----Program
import MathsInfo
print("Val of PI=",MathsInfo.PI)
print("Val of E=",MathsInfo.E)