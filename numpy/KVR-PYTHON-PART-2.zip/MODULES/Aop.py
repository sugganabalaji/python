#Aop.py<----File Name and Module Name
def sumop(a,b):
    print("sum({},{})={}".format(a,b,a+b))
def subop(a,b):
    print("sub({},{})={}".format(a,b,a-b))
def mulop(a,b):
    print("mul({},{})={}".format(a,b,a*b))

