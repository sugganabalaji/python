#MathsInfo.py<-----File Name and acts as Module Name
PI=3.14
E=2.71 # here PI and E are Global Variables

