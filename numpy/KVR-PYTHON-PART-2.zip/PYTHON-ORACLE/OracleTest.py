#OracleTest.py
import oracledb
print(oracledb.__version__)
