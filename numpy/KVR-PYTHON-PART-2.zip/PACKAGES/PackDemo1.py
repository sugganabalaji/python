#PackDemo1.py
import sys
import MathsInfo as m
print("Val of PI=",m.PI)
print("Val of E=",m.E)