#Account6.py<---File Name and Module Name
__acno=100
cname="Travis"
__bal=3.4
__pin=7456
bname="SBI"
def __greet():
    print("Read and Practice well")

# Here acno,cname,bal,pin and bname are called Global Variables
