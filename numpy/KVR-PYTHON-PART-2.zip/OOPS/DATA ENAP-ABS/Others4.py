#Others4.py-----Data Abstraction
from Account4 import Account
ac=Account()
ac.______init__()
print("-----------------------------")
print("Account Number:",ac.acno)
print("Account Holder Number:",ac.cname)
print("Account Balance:",ac.bal)
print("Account Pin:",ac.pin)
print("Account Branch Name:",ac.bname)
print("-----------------------------")


