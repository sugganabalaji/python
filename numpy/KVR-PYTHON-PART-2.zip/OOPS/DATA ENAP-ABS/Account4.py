#Account4.py<----File Name and Module Name<----Data Encapsulation
class Account:
    def ______init__(self): # Constructor is not Possible to encapsulate
        self.acno=100
        self.cname="Rossum"
        self.bal=5.5
        self.pin=1234
        self.bname="SBI"
