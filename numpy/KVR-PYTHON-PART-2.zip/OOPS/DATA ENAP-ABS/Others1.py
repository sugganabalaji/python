#Others1.py-----Data Abstraction
from Account1 import Account
ac=Account()
print("-----------------------------")
#print("Account Number:",ac.acno)
print("Account Holder Number:",ac.cname)
#print("Account Balance:",ac.bal)
#print("Account Pin:",ac.pin)
print("Account Branch Name:",ac.bname)
print("-----------------------------")


