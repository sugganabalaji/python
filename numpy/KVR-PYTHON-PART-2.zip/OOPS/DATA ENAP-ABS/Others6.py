#Others5.py-----Data Abstraction
#from Account6 import acno,bal,pin,greet---Not Possible to Import
from Account6 import cname,bname
print("-----------------------------")
#print("Account Number:",acno)
print("Account Holder Number:",cname)
#print("Account Balance:",bal)
#print("Account Pin:",pin)
print("Account Branch Name:",bname)
print("-----------------------------")
greet()

