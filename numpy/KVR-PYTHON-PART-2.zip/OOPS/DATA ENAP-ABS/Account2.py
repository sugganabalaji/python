#Account2.py<----File Name and Module Name<----Data Encapsulation at Data Member Level
class Account:
    def getaccdet(self):
        self.__acno=100
        self.cname="Rossum"
        self.__bal=5.5
        self.__pin=1234
        self.bname="SBI"
