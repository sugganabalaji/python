#ClassObjectTest.py
class Student:pass

s1=Student() # Student Object Creation
s2=Student() # Student Object Creation
print("ID of s1=",id(s1))
print("ID of s2=",id(s2))
print("----------------------------------")
