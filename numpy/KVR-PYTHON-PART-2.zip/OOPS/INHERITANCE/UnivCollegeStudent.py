#UnivCollegeStudent.py
import Student
s=Student.Student()
s.getstuddet()
s.dispstuddet()