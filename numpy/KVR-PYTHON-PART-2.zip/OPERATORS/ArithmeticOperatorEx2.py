#Program for cal Square Root of a Given Number
#ArithmeticOperatorEx2.py
n=float(input("Enter a Number for Finding Its Square Root:"))
res=n**0.5
print("SquareRoot({})={}".format(n,n**0.5))
