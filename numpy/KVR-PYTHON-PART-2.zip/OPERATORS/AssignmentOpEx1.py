#AssignmentOpEx1.py--Logic-1
a,b=input("Enter Value of a:"),input("Enter Value of b:")
print("-"*50)
print("Original value of a={}".format(a))
print("Original value of b={}".format(b))
print("-"*50)
#Swapping OR Interchaging
a,b=b,a # OR b,a=a,b----------Multi Line assignment
print("Swapped value of a={}".format(a))
print("Swapped value of b={}".format(b))
print("-"*50)
